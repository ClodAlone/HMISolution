//gcc ipldmain.c -L . -l ipld -l curl -o ipld

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include "libipld.h"

#define DOCKER
#ifdef DOCKER
    #define LICENSEVALIDURL "http://emerson-nginx/emerson/pacedge/license/licensevalid.json"
    #define LICENSEURL "http://emerson-nginx/emerson/pacedge/license/license.json"
#else
    #define LICENSEVALIDURL "https://localhost/emerson/pacedge/license/licensevalid.json"
    #define LICENSEURL "https://localhost/emerson/pacedge/license/license.json"
#endif

bool ipldGetLicStatus (char *progea_vsn_string, char *json_buffer, uint32_t *bufsize, uint32_t *result);
bool ipldSetLicenseUrl(char *url);
bool ipldSetLicenseValidUrl(char *url);
bool ipldSetDebug(int val);

int main(int argc, char** argv) 
{
    char json_buffer[400];
    char progea_vsn_string[]="4.3.1";
    int32_t result;
    int32_t bufsize;

    ipldSetLicenseUrl(LICENSEURL);
    ipldSetLicenseValidUrl(LICENSEVALIDURL);
    ipldSetDebug(1);
    bufsize=sizeof(json_buffer);
    printf("IPLD Library Version: %d.%d\n",IPLD_VSN_MAJOR(ipldGetVersion()),IPLD_VSN_MINOR(ipldGetVersion()) );
    if( ipldGetLicStatus (progea_vsn_string, json_buffer, &bufsize, &result) )
    {
        printf("Lincense Valid!\nLicenseinfo:\n%s\n",json_buffer);
    }
    else
    {
        printf("Lincense Invalid!\nResult: %d\nLicenseinfo:\n%s\n",result,json_buffer);
    }
}